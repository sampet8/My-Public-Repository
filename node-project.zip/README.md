# NodeJS ŠTC Project

Commands in order:
- npm install #Install project
- tsc #Compile to JavaScript
- npm run start #Start the project

import App from "./src/App";

new App();